import scrapy
from bs4 import BeautifulSoup


class UstcSpider(scrapy.Spider):
    name = 'ustc'
    allowed_domains = ['yz.ustc.edu.cn']
    start_urls = ['https://yz.ustc.edu.cn/list_1.htm']

    def parse(self, response):
        summer_info = {}
        change_info = {}
        soup = BeautifulSoup(response.text, 'lxml')
        url = "https://yz.ustc.edu.cn"
        infos = soup.find_all('a')
        # print(infos)
        for info in infos:
            title = info.text
            url_href = info.get('href')
            if "调剂" in title:
                if "2021" in title:
                    change_info[title] = url + url_href
            elif "夏令营" in title:
                if "2021" in title:
                    summer_info[title] = url + url_href
        print(summer_info,change_info)