import scrapy


# 创建爬虫类，并且继承自爬虫基础类
class CnblogsSpider(scrapy.Spider):
    name = 'cnblogs'
    allowed_domains = ['cnblogs.com']
    start_urls = ['https://www.cnblogs.com/GuoHail/']

    # 解析响应数据、提取数据或者网址
    def parse(self, response):
        # 提取数据
        # print(response.text)
        title = response.xpath('/html/body/div[2]/div[2]/div[1]/div/div[2]/div[2]/a/span/text()').get()
        href = response.xpath('/html/body/div[2]/div[2]/div[1]/div/div[2]/div[2]/a/@href').get()
