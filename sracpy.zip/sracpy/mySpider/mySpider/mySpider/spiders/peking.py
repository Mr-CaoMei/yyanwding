import scrapy
from bs4 import BeautifulSoup

class PekingSpider(scrapy.Spider):
    name = 'peking'
    allowed_domains = ['admission.pku.edu.cn']
    start_urls = ['https://admission.pku.edu.cn/xly/index.htm?CSRFT=AQJ4-1F1G-N5T6-4SUM-YV8D-WCM1-LSWI-0Y2C']

    def parse(self, response):
        summer_info = {}
        change_info = {}
        soup = BeautifulSoup(response.text, 'lxml')
        div_list = soup.find('div', class_='zsxx_cont_r fr')
        # print(div_list)
        li_list = div_list.find('ul', class_='zsxx_cont_list')
        li_list = li_list.find_all('li')
        for info in li_list:
            title = info.find('a').find('p').string
            #print(title)
            url_href = info.find('a').get('href')
            #print(url_href)
            if "调剂" in title:
                if "2021" in title:
                    change_info[title] = url_href
            elif "信息" in title:
                if "2021" in title:
                    summer_info[title] = url_href
        print(summer_info, change_info)